import java.util.Scanner;

public class Ex07_printf_format {

	public static void main(String[] args) {
		
		// System.out.println()
		// c# : Console.WriteLine();
		
		System.out.println("A"); // 출력하고 줄바꿈
		System.out.println();//엔터 줄바꿈
		System.out.println("B");
		
		int num=1000;
		System.out.println(num);
		System.out.println("num 값은 " + num + " 입니다");
		
		//형식(format)
		System.out.printf("num 값은 %d 입니다", num); //내부적으로 개행하지 않아요
		System.out.println();
		System.out.printf("num 값은 [%d] 입니다 또 [%d] 도 있어요\n", num,12345);
		
		/*
		 %d 10진수 형식의 정수
		 %f 실수
		 %s 문자열 
		 %c 문자
		 
		 \t , \n 조합해서 format 생성
		 		  
		*/
		float f = 3.14f;
		System.out.println(f);
		System.out.printf("f 변수값은 %f 입니다\n",f);
		
		//cmd 모드 입력값 받기 ^^
		
		Scanner sc = new Scanner(System.in); //입력값 받는 클래스
		//String value = sc.nextLine(); //무었인가 입력하고 enter 할때까지 대기 
		//프로그램이 종료 되지않고 계속대기
		//System.out.println("value 입력값 : " + value);
		
		//float value = sc.nextFloat();
		//System.out.println("value 입력값 : " + value);
		
		//Tip 
		//권장 : nextInt  , nextFloat 보다는 모든 데이터를 nextLine() read 
		//필요하면 타입 변환
		
		//Today Point
		//[문자열] -> 숫자(정수, 실수)
		
		/*
		  String data =sc.nextLine();
		  int age = Integer.parseInt(data);
		  
		  Integer.parseInt("1000") -> 1000
		  Float.paserFloat("3.1452") -> 3.1452

		 */
		System.out.println("숫자를 입력하세요");
		int number = Integer.parseInt(sc.nextLine());
		System.out.printf("입력한 숫자는 : %d",number);
	}

}
