import java.util.Scanner;

public class Ex08_Operation_Quiz {

	public static void main(String[] args) {
		/*
		 /*
		간단한 사칙 연산기 (+ , - , * , /)
		입력값 3개 (입력값은 nextLine() 받아서 필요하다면 숫자 변환)
		목적 : Integer.parseInt() ,  ** 구글 java equals() 활용  문자열의 비교** 

		화면
		>입력값:숫자
		>입력값(기호): +
		>입력값:숫자 
		>연산결과 :200
		-------------
		>입력값:100
		>입력값(기호): -
		>입력값:100
		>연산결과 :0 

	hint)
	if 조건값이 boolean
	switch  문은 정수형(byte, short , int) 와  문자(char) , 문자열(String) 조건식 사용
	
	Scanner sc = new Scanner(System.in);
	System.out.print("입력값(숫자):")
	String ch = sc.nextLine();

    switch(ch) {
       case "+" : 더하기 처리
    }
    */
    
	// equals 알아보기 
	/*
	  == 연산자는 값을 비교  
    */
	String str1 = "AAA";
	String str2 = "AAA";
	
	System.out.println(str1 == str2);
	//같은 값인지를 판단
	//str1  과 str2 같은 메모리 참조 (주소 동일) 
	
	String str3 = new String("BBB");
	String str4 = new String("BBB");
	System.out.println(str3 == str4);	
	//문자열 비교는  equals 써라 (주소값 비교 말고 그 안에 값을 비교)
	System.out.println(str3.equals(str4));
	
	
	Scanner sc = new Scanner(System.in);
	String op =  sc.nextLine();
	System.out.println(op == "+");
	System.out.println(op.equals("+"));
	
   }

}
