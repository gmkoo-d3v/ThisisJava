/*
1. 자바가 제공하는 기본 타입(원시타입) >> 8가지
2. 8가지 타입은 값을 저장 하는 타입
숫자    정수(음의정수 0 양의정수)   byte(8bit) -128 ~ 127
                             char(2byte) 한문자 (내부적으로는 정수값) 
                             영문자,특수문자,공백 (1byte) , 한글 1자(2byte)
                             협의 (국제) >> 모든 문자는 2byte >> 표준화 >> unicode >> 아스키 코드표
      						 ex) char c = 'A' , char ch = '가'
      						 short 호환성 
      						 int (4byte -21 ~ 21) **~~ ** 정수 리터럴의 기본 타입 int 
      						 long (8byte)
       실수(부동소수점)          float (4byte) 7자리 정도의 소수 표현 가능
                             double(8byte) 15자리 정도의 소수 표현 가능
                             (boolean) 정밀도가 높다(표현 범위가 크다) **~~** 실수 리터럴의 기본 타입 double  
논리                          참 거짓을 표현하는 타입 (true, false) 판단 

현재는 대충 ....
정수는 int , 실수는 double 타입을 사용하면 별 문제 없다

가장 많이 사용되는 타입 (String)
String str="홍길동";
우리가 가장 많이 사는 String 은 클래스 입니다 
String 타입은 문자열을 담을 수 있습니다
ex) String str = new String("홍길동");
약속) 별도의 이야기 ..... 8가지 기본 타입 + 1(String) >> String 은 int , long 처럼 쓰세요

자바 타입은
1. 값타입 : 8 + 1 (값을 저장)
2. 참조타입 (주소값을 저장) : 클래스 , 인터페이스 , 배열 등등 .....

[정수값을 표기하는 방법]
100      십진수
0x2a     16진수 
0123     8진수 
0b11010  2진수
123L or 123l    리터럴 long 타입 십진수 **
Ox2aL           리터럴 long 타입 16진수

[실수값을 표기하는 방법]
3.14
123.4
123.4F , 123.4f
1.234e2승 >> 123.4 값을 지수표기법
1.234e2승f

문자값을 표기하는 방법
'A' or  '가'
'\u0065'

진리값을 표기하는 방법
true
false

문자열을 표기하는 방법
"홍길동"
"ABCD"

*/
public class Ex03_DataType {
	public static void main(String[] args) {
		
		// int(-21 ~ 21)
		int num = 100000000;
		System.out.println("num : " + num);
		
		//int num2 = 10000000000; 
		int num2 = 10000; 
		//The literal 10000000000 of type int is out of range 
		
		long num3 = 100;
		//사실은 컴파일러가 내부적으로 일을 해요
		// long num3= (long)100;
		// 암시적 형변환 (컴파일러가 자동으로 형변환)
		// 작은 타입을 큰 타입 넣는 것은 당근 ....
		
		//초보 개발자 주의사항
		//int num4 = 10000000000;
		//int num4 = 10000000000L;
		//long num4 = 10000000000L; // 해결방법 1
		
		//개발자의 의도 명시적 형 변환 (타입 변환 ,casting)
		//정상적인 값이 안나오는 경우 발생 (쓰레기 값 ,,, 버려지는 값)
		int num4 = (int)10000000000L; 
		System.out.println("num4 " + num4);
		
		//int num5 = (int)100000L; 
		//데이터 손실은 없어요  
		
		//답) 담을 그릇을 크게 
		
		
		//char 2byte > 한문자 표현 > 정수값(0~65535)
		//아스키 코드표 (a 문자 > 65 )
		
		char ch ='가';
		System.out.println(ch);
		
		ch = 'a';
		ch = 'A';
		
		//char 정수 타입 (문자를 저장하지만 내부적으로 정수값을 가지고 있다)
		
		int chint = ch;
		System.out.println("ch 문자를 정수 값으로 보면 : " + chint);
		
		//int chint = (int)ch;
		
		char chint2 = 'a';
		System.out.println(chint2);
		
		//int intch2 = (int)chint2; 명시적 형변환
		
		
		//문제 제시
		//int intch3 = 65;
		
		//char ch3 = intch3;
		
		//1 해결방법 (명시적 형변환 데이터 손실이 발생 할 수 도 있다)
		//char ch3 = (char) intch3;
		
		//2 해결방법  (받는 그릇을 크게)
		//int ch3 = intch3;
		
		/*
		 1. 할당에 있어서 값을 보지말고 값이 가지는 타입을 보자
		 1.1 리터럴 값에 대해서 (개발자가 직접 입력하는 값)
		 1.1.1 정수 리터럴의 기본 타입은 int
		 1.1.2 실수 리터럴의 기본 타입은 double 
		 
		 2. 암시적 형변환 , 명시적 형변환
		 2.1 큰 타입에 작은 타입의 값을 넣는 것은 암시적 형변환을 통해서 개발자 고고 
		 2.2 작은 타입에 큰 타입을 넣고자 한다면 자동 형변환 지원하지 않아요 (강제적)명시적 형변환
		 2.2.1 접미사( L , l) 또는 (int)정수 
		 KEY POINT : 강제적 형변환은 데이터 손실을 감수 (책임은 개발자) 
		 ex) char c = (char)int 손실발생 가능성 ^^
		 
		 String 8+1(String) 
		 값타입 처럼 써도 문제 없다
		 문자열 "가나다" >> ['가']['나']['다'] >> 문자열의 char 집합
		 int , long 동일하게 사용
		 */
		String name = "홍길동";
		name = "홍길동 바보";
		
		String color="red";
		color = color + " 방가방가";
		System.out.println(color);
		
		//TIP)
		//연산자 언어마다 표현이 달라요
		//JAVA > + 산술 , 결합
		//Oracle > + 산술 ,  결합 연산자 ||  > '안녕' || '방가방가'
		
		//TIP)
		//자바는 타입에 엄격한 언어 
		/*
		  let i;
		  i = 100; 이때 타입이 결정 (number) 
		*/
		//Java 에서 특수문자 처리하기
		//char sing =' ';
		//char sing ='''; //Invalid character constant
		//이스케이프 문자 : 특정 문자앞에 \다음 값은 데이터 인정
		char sing = '\'';
		System.out.println(sing);
		
		//Quiz) 홍"길"동 이라는 문자열을 출력하고 싶어요
		String userName = "홍\"길\"동";
		System.out.println(userName);
		
		String str1 = "10000";
		String str2 = "10";
		String result = str1 + str2; //결합
		System.out.println("result : " + result);
		
		System.out.println("100" + 100); //100100
		System.out.println(100 + "100"); //100100 
		System.out.println(100 + 100 + "100");//200100
		System.out.println(100 + (100+"100"));//100100100
		System.out.println(100 + "100" + 100);//100100100
		
		//Quiz  경로 C:\Temp 문자열로 String 변수에 담아서 출력해보세요
		String path = "C:\\Temp"; 
		System.out.println("path : " + path);
		//Invalid escape sequence (valid ones are  \b  \t  \n  \f  \r  \"  \'  \\ )
	
		// \t , \n (new line)
		path = "C:\\T\te\tm\np";
		System.out.println("path : " + path);
		
		//byte : 네트워크 데이터 교환 .. 파일처리 (파일 업로드 다운로드)  
		//byte[] ...배열로 활용
		//long : 금융 화폐
		
		
		//실수형 (부동소수점)
		//float 4byte
		//double 8byte (실수 리터럴의 기본 타입 : double)
		//float f = 3.14;
		
		float f = 3.14f;
		float f2 = (float)3.14;
		//데이터 손실이 발생
		
		//현명한 개발자
		double d = 3.14;
		//처음부터 타입을 크게 잡고 
		
		float data = 1.123456789f; //8에서 반올림  7값이 8이되요
		System.out.println("float data : " + data);
		//float data : 1.1234568 
		
		double data2 = 1.123456789123456789;
		System.out.println("double data2 : " + data2);
		//double data2 : 1.1234567891234568   반올림
		
		//***자바는   BigDecimal 클래스를 만들어 정밀한 수 (화페 단위) *****
		
		//Quiz 1)
		double data3 = 100;
		//결과값
		System.out.println("data3 : " + data3); //100.0
		
		//Quiz 2)
		double data4 = 100;
		int number = 100;
		//   double + int 결과 double
		//int result2 = data4 + number;
		//int result2 = (int)(data4 + number); // 손실이 발생할 수도
		double result2 = data4 + number; //선택 (받는 쪽을 크게)
		
		
		//Quiz 3)
		int number2 = 100;
		//byte b2 = number2;
		//byte b2 = (byte)number2;
		//int b2 = number2;
		
		//Today Point
		//1. 큰타입 + 작은 타입 연산결과는 큰타입
		//2. 타입간 변환 >> 변수가 가지는 값을 보지말고 변수의 타입을 보자
		//3. 명시적(강제적) 형변환 데이터 손실 가져올 수 있다 (고민)
		
		int data5 = 100;
		byte b3 = (byte)data5; //명시적 (강제적) 형변환
		
		byte b4 = 20;
		//int data6 = b4;
		//int data6 = (int)b4; //컴파일러가 자동으로 처리하는 코드는 ...암시적 변환
		int data6 = b4;
	}

}



