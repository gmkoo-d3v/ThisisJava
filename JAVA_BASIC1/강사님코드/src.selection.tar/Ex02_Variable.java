import kr.or.kosa.Emp;

public class Ex02_Variable {
	public static void main(String[] args) {
		
		//변수 정의
		//타입이란
		//제어문 ....
		
		int value; //변수 선언 (지역변수) 선언은 되어있지만 초기화 되지 않았다
		//System.out.println(value);
		//The local variable value may not have been initialized

		//초기화 : 변수의 초기화 : 변수 [처음 값]을 갖는 것 (할당을 통해서)
		//지역변수는 사용시 반드시 초기화를 선행 해야 한다
		//지역변수(local) 무조건 초기화 해라 ....
		value =100; 
		
		//선언과 할당을 동시에
		int age = 50;
		System.out.println(age);
		
		Emp emp; //선언 (지역변수)
		//System.out.println(emp);
		//초기화 
		emp = new Emp(); //주소값 할당 (초기화)
		
		// new 연산자 클래스 구체화 메모리에 할당 > heap > 생성된 메모리 주소 생성
		//System.out.println(emp);
		//kr.or.kosa.Emp@73a28541
		
		// .연산자를 주소를 찿아가는 연산자
		//System.out.println(emp.empno);
		
		Emp emp2 = emp;
		emp2.empno = 5000;
		System.out.println(emp.empno); //주소값 할당 
		System.out.println(emp2 == emp); //동거하는 구나
		
		
		//변수 > 데이터 타입 > 연산자 > 제어문 초급
		//객체지향 (상속, 다형성 , 캡슐화)
		
		int a , b , c; //같은 타입의 변수를 나열 >> 개발자 >> 배열 int[] arr
		a= 100;
		b= 200;
		c= 300;
		//권장하지 않아요
		
		//int a = 500; //Duplicate local variable a
		
		int result = a+b; //result 초기화 
		System.out.println("result 값은 : " + result);
		
	}

}
