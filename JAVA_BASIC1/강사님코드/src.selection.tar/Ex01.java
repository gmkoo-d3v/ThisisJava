import kr.or.kosa.Car;
import kr.or.kosa.Emp;

public class Ex01 {
	public static void main(String[] args) {
		//System.out.println("hello");

		//모든 클래스는 메모리에 올라가야 사용가능
		//현실 아파트 설계도 (종이) > 구체화 > 땅 집을 짓는 것 > 주소 건물
		int i= 10;
		Emp e = new Emp();
		e.empno = 7788;
		e.ename = "홍길동";
		//e.data = 10000;
		e.Info();
		
		//자동차 만들기
		//메모리에 올리자 (문법)
	   Car samsungCar = new Car();
	   samsungCar.carInfoPrint();
	   samsungCar.setDoor(2);
	   samsungCar.setCarColor("red");
	   samsungCar.carInfoPrint();
	   
	   Car lgCar = new Car();
		
	}

}
